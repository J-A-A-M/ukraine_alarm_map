HALight class
=============

.. doxygenclass:: HALight
   :project: ArduinoHA
   :members:
   :protected-members:
   :private-members:
   :undoc-members: