HASwitch class
==============

.. doxygenclass:: HASwitch
   :project: ArduinoHA
   :members:
   :protected-members:
   :private-members:
   :undoc-members: