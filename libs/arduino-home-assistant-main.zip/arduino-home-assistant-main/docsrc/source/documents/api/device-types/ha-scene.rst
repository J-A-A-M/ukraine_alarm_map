HAScene class
=============

.. doxygenclass:: HAScene
   :project: ArduinoHA
   :members:
   :protected-members:
   :private-members:
   :undoc-members: