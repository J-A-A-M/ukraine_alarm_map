HASensor class
==============

.. doxygenclass:: HASensor
   :project: ArduinoHA
   :members:
   :protected-members:
   :private-members:
   :undoc-members: