HADeviceTracker class
=====================

.. doxygenclass:: HADeviceTracker
   :project: ArduinoHA
   :members:
   :protected-members:
   :private-members:
   :undoc-members: