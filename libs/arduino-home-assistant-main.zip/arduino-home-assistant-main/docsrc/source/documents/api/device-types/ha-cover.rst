HACover class
=============

.. doxygenclass:: HACover
   :project: ArduinoHA
   :members:
   :protected-members:
   :private-members:
   :undoc-members: