HAUtils class
=============

.. doxygenclass:: HAUtils
   :project: ArduinoHA
   :members:
   :protected-members:
   :private-members:
   :undoc-members: