---
name: All others
about: If your issue doesn't fit the other two, this will guide you to support.
title: "[DELETE ME]"
labels: NOT AN ISSUE
assignees: ''

---

### STOP
If you are seeking support, then please use the Discussions feature or gitter channel by following one of these links.  
[NeoPixelBus Discussions](https://github.com/Makuna/NeoPixelBus/discussions)  
[NeoPixelBus Gitter Channel](https://gitter.im/Makuna/NeoPixelBus)  

If you submit issues that are not traceable bugs or feature requests, it will just get closed.
